How to run/use the program:

- double click or right click "Academic Foundations Calculator.bat" and press open
- input the Essay Score First, then press enter
- input the NGR score, then press enter

Depending on what scores you enter, you might have to scroll up to view everything in the command prompt.

TO-DO:

- color code the command prompt
- have the classes separated into two columns in the command prompt

GOAL:

- Have a graphical user interface (GUI/UI)


DONE:

- input validation for essay score (you cannot enter a score lower than 0 and higher than 8)
- input validation for NGR score